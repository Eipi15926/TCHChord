from music21 import converter, note, chord, stream, meter, key, interval, pitch
from parser.parse import sharps_to_semitone

def parse_melody(midi_file):
    midi = converter.parse(midi_file)
    melody_list = []
    k = midi.analyze('key')
        
    sharps = k.sharps
    semitone_offset = sharps_to_semitone[sharps]
    midi = midi.transpose(semitone_offset)
    for m in midi.recurse(classFilter='Measure'):
        cur_notes = [0] * 12
        for n in m.recurse(classFilter='Note'):
            p = int(n.pitch.pitchClassString, 16) # n.pitch.pitchClassString is a hexadecimal integer, index
            cur_notes[p] = 1
        melody_list.append(cur_notes)
        
    return melody_list
