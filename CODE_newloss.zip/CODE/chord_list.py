import torch
chord_list = []
# 生成和弦向量表
start = 9
for i in range(12):
    chord_major = [0] * 12
    chord_minor = [0] * 12
    chord_major[start] = 1
    chord_major[(start + 4) % 12] = 1
    chord_major[(start + 7) % 12] = 1
    chord_minor[start] = 1
    chord_minor[(start + 3) % 12] = 1
    chord_minor[(start + 7) % 12] = 1
    chord_list.append(chord_major)
    chord_list.append(chord_minor)
    
    chord_minor_minor = chord_minor.copy()
    chord_minor_major = chord_minor.copy()
    chord_minor_minor[(start + 10) % 12] = 1
    chord_minor_major[(start + 11) % 12] = 1
    
    chord_major_minor = chord_major.copy()
    chord_major_major = chord_major.copy()
    chord_major_minor[(start + 10) % 12] = 1
    chord_major_major[(start + 11) % 12] = 1
    
    chord_list.append(chord_major_major)
    chord_list.append(chord_major_minor)
    chord_list.append(chord_minor_major)
    chord_list.append(chord_major_minor)
    
    start = (start + 1) % 12

chord_list = torch.tensor(chord_list)
print(chord_list)