from music21 import *

# filepath = 'data\\all_key\\a-a-day-to-remember-downfall-of-us-all-intro-and-verse_key.mid'
filepath = 'data\\all_key\\a-afta-1-ahmad-instrumental_key.mid'
# filepath = 'test.mid'
midi_file = converter.parse(filepath)
midi_file.show('text')
# k = midi_file.recurse().getElementsByClass(chord.Chord)[0]
# print(k)
# parts = midi_file.recurse(classFilter='Part')
# for m in parts[1].recurse(classFilter='Measure'):
    # for c in list(m.recurse(classFilter='Note')):
    #     print(c)
    # print(m)
    # if(m.recurse(classFilter='Chord')):
    #     print(list(m.recurse(classFilter='Chord')))
    # for n in m.recurse(classFilter='Note'):
    #     print(int(n.pitch.pitchClassString, 16))
    # for c in m.recurse(classFilter='Chord'):
    #     for p in c.pitches:
    #         print(p.pitchClassString)
    #     print('-------')
    # print(c.pitches[0].pitchClassString)
# midi_file.show('text')
# TimeSig = midi_file.recurse().getElementsByClass(meter.TimeSignature)[0]
# print(TimeSig.numerator, TimeSig.denominator) # get time signature 得到拍号
# KeySig = midi_file.recurse().getElementsByClass(key.KeySignature)[0]
# print(KeySig, KeySig.sharps) # get key signature 得到调号
# for n in midi_file.recurse().notes:
#     n.transpose(-1, inPlace=True) # try transposing 尝试移调
print('------------------')
# midi_file.show('text')
