import model.model_BLSTM
import torch

m = torch.load('save/mymodel_230327.pt')
m.eval_config['lim_num'] = 4
m.test()
