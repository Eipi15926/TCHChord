from torch.autograd import Variable
import torch.nn as nn
import torch
class MyLossFunc(nn.Module):
    def __init__(self):
        super(MyLossFunc, self).__init__()

    def forward(self, out, label):
        # out = Variable(out, requires_grad = True)
        a = label.size()
        loss = Variable(requires_grad=True)
        scprod = (out * label).sum(2)
        loss = (1 - scprod/(((out*out).sum(2)*(label*label).sum(2)+1e-6)**0.5)).sum()/(a[0]*a[1])
        # print((out*out).sum(2))
        # print((label*label).sum(2))
        # print(loss)
        return loss

# how to use:
'''
loss_function = MyLossFunc()
if cuda_available:
    loss_function.cuda()

for data in train_loader:  # 对于训练集的每一个batch
    img, label = data
    if cuda_available:
        img = img.cuda()
        label = label.cuda()

    out = cnn(img)  # 送进网络进行输出
    # print('out size: {}'.format(out.size()))
    # print('label size: {}'.format(label.size()))

    # out = torch.nn.functional.softmax(out, dim=1)
    loss = loss_function(out, label)  # 获得损失

    optimizer.zero_grad()  # 梯度归零
    loss.backward()  # 反向传播获得梯度，但是参数还没有更新
    optimizer.step()  # 更新梯度
'''