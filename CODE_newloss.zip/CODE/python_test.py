import torch
a = torch.tensor(1)
print(a)
a = 2 * a
print(a)