from music21 import *
from model.metric_new import mapping
from parse_melody import parse_melody
import torch

INT_TO_NOTE = {}

def chord_to_str(chord):
    index = torch.tensor(range(12))
    notes = index[chord]
    chord_str = []
    for note in notes:
        chord_str.append(INT_TO_NOTE[note])
    return chord_str
    

threshold = 0.5
midi_file = ''
model_path = ''
model = ''

melody = parse_melody(midi_file)
melody = torch.tensor(melody)
chord_output = model(melody)
for c in chord_output:
    c = (c >= threshold)
    chord_str = chord_to_str(c)
    